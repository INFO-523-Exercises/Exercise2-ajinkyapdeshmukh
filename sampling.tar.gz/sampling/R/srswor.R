"srswor" <-
function(n,N)
{s<-rep(0,times=N);s[sample.int(N,n)]<-1;s}

